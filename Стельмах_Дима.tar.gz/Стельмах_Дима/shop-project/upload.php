<?php
header("Content-Type: text/html; charset=utf-8");

require_once('all-functions.php');

// Проверяем есть ли файл с таким именем
$fileName = $_FILES["uploadfile"]["name"];
if (!isset($fileName)) {
    echo 'Файл с таким именем не существует.';
    echo returnHomeForm();
}
$fileDir = __DIR__ . '/upload-file/' . $fileName;
$isFileUpload = is_uploaded_file($_FILES["uploadfile"]["tmp_name"]);
if ($isFileUpload) {
    // Если файл загружен успешно, перемещаем его
    // из временной директории в конечную
    move_uploaded_file($_FILES["uploadfile"]["tmp_name"], $fileDir);
    echo 'Файл загружен успешно в папку: ' . $fileDir;
} else {
    echo 'Ошибка загрузки файла';
    echo returnHomeForm();
}

// Открытьи изначального файла в формате .CSV
$readFile = workWithFile($fileDir);

// Разделение изначального файла на строки
$fileContent = explode("\n", trim($readFile));

// Разделение титлов
$titles = explode(";", trim($fileContent[0]));

/**
 *Цикл дляприведения изначаьлного файла в необходимый вид
 */
//var_dump($fileContent); die;
$groupedItems = [];
foreach ($fileContent as $key => $rows) {
    // Пропускаем первуб строку, где находятся титлы
    if ($key == 0) {
        continue;
    }

    $row = explode(";", trim($rows));

    // Получаю массив в которм ключи-значения превого массива, значения-значения второго массива
    $groupedItems[] = array_combine(titlesCorrectFormat($titles), $row);
    // Принудительная установка указателя на необходимый ключ, для дальнейшей работы
    end($groupedItems);
    $lastInd = key($groupedItems);
    // Форматирование
    $groupedItems[$lastInd]['sku'] = correctItems($groupedItems[$lastInd]['sku'], 'sku');
    $groupedItems[$lastInd]['price'] = correctItems($groupedItems[$lastInd]['price'], 'price');
    $groupedItems[$lastInd]['special_price'] = correctItems($groupedItems[$lastInd]['special_price'], 'special_price');

    $sku = $groupedItems[$lastInd]['sku'];
    $color_id = $groupedItems[$lastInd]['color_id'];
    // Добавление в массив image_url
    $groupedItems[$lastInd] += ['image_url' => gatherImageUrl($sku, $color_id)];

    // Пременная для записи массива в файл в файл
    $itemsForWriting = '';
    // Перебор массива массива и формирование $itemsForWriting
    foreach ($groupedItems[$lastInd] as $key2 => $value) {
        $itemsForWriting .= $key2 . ':' . $value . "\n";
    }
    // Запись в файлы enable/disable

    if ($groupedItems[$lastInd]['is_enabled'] == 'yes') {
        file_put_contents(__DIR__ . '/products/enabled/' . $groupedItems[$lastInd]['sku'] . ".txt", $itemsForWriting);
    } else {
        file_put_contents(__DIR__ . '/products/disabled/' . $groupedItems[$lastInd]['sku'] . ".txt", $itemsForWriting);
    }

}


// Вывод на экран
$enabledDirectoryPath = __DIR__ . '/products/enabled/';
$allFilesDirectory = scandir($enabledDirectoryPath);
$allFiles = array_diff($allFilesDirectory, array('..', '.'));
$fileContentForTitles = explode("\n", file_get_contents($enabledDirectoryPath . $allFiles[2]));
$fileTitles = [];
foreach ($fileContentForTitles as $value) {
    $str = explode(":", $value)[0];
    if ($str)
        $fileTitles[] = $str;
}
?>
<div>
    <table border="1">
        <tr>
            <?php foreach ($fileTitles as $colTitle) { ?>
                <th><?php echo $colTitle ?></th>
            <?php } ?>
        </tr>
        <?php foreach ($allFiles as $key3) { ?>

            <tr>
                <?php $fileContentArr = array_diff(explode("\n", file_get_contents($enabledDirectoryPath . $key3)), array('')); ?>
                <?php foreach ($fileContentArr as $key => $value) { ?>
                    <?php if (explode(':', $value)[0] !== 'image_url') { ?>
                        <?php if (explode(':', $value)[0] == 'price' && explode(':', $fileContentArr[$key + 1])[1] != 0){ ?>
                            <td><s><?php echo explode(':', $value)[1];?></s></td>
                        <?php }else{?>

                        <td><?php echo explode(':', $value)[1]; ?></td>
                            <?php }?>
                    <?php } else { ?>
                        <?php $imgUrlArr = explode(':', $value); ?>
                        <?php $imgUrl = $imgUrlArr[1] . ':'. $imgUrlArr[2] ?>
                        <td><img width="50" height="100" src="<?php echo $imgUrl; ?>" /></td>
                    <?php } ?>
                <?php } ?>

            </tr>
        <?php } ?>
    </table>
</div>
<!--var_dump($scanned_directory);-->