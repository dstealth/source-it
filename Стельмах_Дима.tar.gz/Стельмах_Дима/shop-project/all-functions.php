<?php

// Создает кнопку для возрата на домашнюю страницу
function returnHomeForm()
{
    $formDir = __DIR__ . '/return-home-form.html';
    $openForm = fopen($formDir, 'r');
    $readForm = fread($openForm, filesize($formDir));
    fclose($openForm);
    return $readForm;
}

// Работате с файлом
function workWithFile($fileDir)
{
    if (file_exists($fileDir)) {
        $openFile = fopen($fileDir, "r");

        $readFile = fread($openFile, filesize($fileDir));

        $closeFile = fclose($openFile);
        return $readFile;
    } else {
        echo 'Файлы не существует';
    }
}


// Форматирует наименования характеристик товара
function titlesCorrectFormat($titles)
{
    $result = [];
    foreach ($titles as $key => $title) {
        $title = strtolower($title);
        $title = str_replace(" ", "_", $title);
        $title = str_replace("?", "", $title);
        $result[] = $title;
    }
    return $result;
}

// Форматирует характеристики товара
function correctItems($item, $format)
{
    switch ($format) {
        case 'sku':
            return str_replace(" ", "-", $item);
            break;
        case 'price':
        case 'special_price':
            $bar = str_replace(",", ".", $item);
            return floatval($bar);
            break;
    }
}

// Возвращает URL для картинки каждого товара
function gatherImageUrl($sku, $color_id)
{
    return 'http://cdn.richandroyal.de/media/external/D/' . $sku . '_' . $color_id . '_1_455.jpg';
}